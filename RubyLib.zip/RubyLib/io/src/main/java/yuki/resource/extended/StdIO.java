package yuki.resource.extended;

/**
 * Created by Akeno on 2016/10/24.
 */

public class StdIO {
    public String Output="";
    public String Error="";
}
