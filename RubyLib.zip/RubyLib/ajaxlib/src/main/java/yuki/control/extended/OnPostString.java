package yuki.control.extended;

/**
 * Created by Akeno on 2016/08/31.
 */
public interface OnPostString extends OnPost {
    public void Post(String data);
}
