package yuki.control.extended;

/**
 * Created by Akeno on 2017/08/04.
 */

public interface OnRESTString extends OnREST {
    public void REST(String data);
}
