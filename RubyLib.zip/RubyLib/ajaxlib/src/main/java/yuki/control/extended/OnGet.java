package yuki.control.extended;

/*OnGet Response Handler*/
public interface OnGet {

}
