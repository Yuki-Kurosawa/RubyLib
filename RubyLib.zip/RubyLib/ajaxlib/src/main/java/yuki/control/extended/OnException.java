package yuki.control.extended;

/**
 * Created by Yuki on 2018-02-05.
 */

/* On Exception Handler*/
public interface OnException {

    public void OnError(Exception error);
}
